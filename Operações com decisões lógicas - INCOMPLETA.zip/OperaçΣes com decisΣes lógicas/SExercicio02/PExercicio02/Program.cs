﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.WriteLine("Digite dois valores quaisquer e obtenha o maior na sua tela");
            Console.WriteLine("Digite o primeiro valor");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor");
            b = double.Parse(Console.ReadLine());

            if (a > b)
            {
                Console.WriteLine("O maior valor digitado foi o primeiro");
            }
            else
            {
                if (b > a) 
                {
                    Console.WriteLine("O maior valor digitado foi o segundo");
                }
                else
                if ( a == b)
                if ( b == a)
                {
                    Console.WriteLine("Os valores são iguais");

                }
            }
            Console.ReadLine();
            

        }
    }
}
