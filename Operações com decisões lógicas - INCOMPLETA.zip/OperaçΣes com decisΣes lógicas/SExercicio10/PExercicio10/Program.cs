﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double média;
            double x;


            Console.WriteLine("Obtenha o seu resultado final");
            Console.WriteLine("Digite o valor da p1");
            p1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da p2");
            p2 = double.Parse(Console.ReadLine());

            x = 2 * p2;
            média = (p1 + x) / 3;

            if (média >= 5) 
            {
                Console.WriteLine("Aprovado");

            }
            else
                if (média < 5) 
            {
                Console.WriteLine("Reprovado");
            }
        }
    }
}
