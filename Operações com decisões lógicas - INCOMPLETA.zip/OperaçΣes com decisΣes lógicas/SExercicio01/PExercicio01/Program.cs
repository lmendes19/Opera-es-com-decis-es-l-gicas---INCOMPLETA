﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.WriteLine("Digite dois valores distintos e obtenha o maior na sua tela");
            Console.WriteLine("Digite o primeiro valor");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor");
            b = double.Parse(Console.ReadLine());

            if ( a>b )
            {
                Console.WriteLine("O maior valor foi o primeiro digitado");
            }
            else
            {
                if (b > a) ;
                Console.WriteLine("O maior valor foi o segundo digitado");
            }
            Console.ReadLine();
        }
    }
}
